﻿namespace HTTPServer.Server.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
