﻿namespace HTTPServer.Server.Contracts
{
    public interface IView
    {
        string View();
    }
}
