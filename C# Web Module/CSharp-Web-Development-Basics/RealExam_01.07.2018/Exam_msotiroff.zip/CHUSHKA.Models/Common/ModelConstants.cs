﻿namespace CHUSHKA.Models.Common
{
    public class ModelConstants
    {
        public const int UserUsernameMinLength = 3;

        public const int ProductNameMinLenght = 3;
        public const int ProductNameMaxLenght = 20;
    }
}
