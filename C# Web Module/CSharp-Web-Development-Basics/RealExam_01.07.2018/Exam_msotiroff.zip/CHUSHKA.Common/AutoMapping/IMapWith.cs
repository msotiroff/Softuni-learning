﻿namespace CHUSHKA.Common.AutoMapping
{
    // Marker interface
    public interface IMapWith<TModel>
    {
    }
}
