﻿namespace CHUSHKA.Common.Notifications
{
    public enum NotificationType
    {
        Success,
        Info,
        Warning,
        Error
    }
}
