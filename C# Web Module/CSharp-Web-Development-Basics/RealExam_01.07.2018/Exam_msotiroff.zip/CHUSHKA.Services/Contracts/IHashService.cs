﻿namespace CHUSHKA.Services.Contracts
{
    public interface IHashService
    {
        string ComputeHash(string text);
    }
}
