﻿namespace CHUSHKA.Services.Contracts
{
    // Marker interface
    public interface IService
    {
    }
}
