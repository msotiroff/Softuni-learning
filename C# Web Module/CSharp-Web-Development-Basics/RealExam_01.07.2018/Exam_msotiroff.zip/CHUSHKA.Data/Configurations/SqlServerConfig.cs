﻿namespace CHUSHKA.Data.Configurations
{
    public class SqlServerConfig
    {
        internal const string ConnectionString = @"Server=.\SQLEXPRESS;Database=ChushkaDb_msotiroff;Integrated Security=True";
    }
}
