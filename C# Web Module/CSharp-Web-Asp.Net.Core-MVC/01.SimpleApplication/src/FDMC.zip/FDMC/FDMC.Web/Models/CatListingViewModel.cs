﻿namespace FDMC.Web.Models
{
    public class CatListingViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Breed { get; set; }

        public string ImageUrl { get; set; }
    }
}
