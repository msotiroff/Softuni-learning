﻿namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-LRMHUDK\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security = True";
    }
}