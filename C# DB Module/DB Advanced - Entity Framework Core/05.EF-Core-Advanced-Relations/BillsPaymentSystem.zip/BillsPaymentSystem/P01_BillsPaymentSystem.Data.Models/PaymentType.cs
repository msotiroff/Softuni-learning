﻿namespace P01_BillsPaymentSystem.Data.Models
{
    using System;

    public enum PaymentType
    {
        BankAccount,
        CreditCard
    }
}