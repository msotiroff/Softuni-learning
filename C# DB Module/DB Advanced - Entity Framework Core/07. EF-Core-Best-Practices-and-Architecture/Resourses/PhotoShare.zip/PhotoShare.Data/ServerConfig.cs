﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        internal static string ConnectionString => "Server=.;Database=PhotoShare;Integrated Security=True;";
    }
}
