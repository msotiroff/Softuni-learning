﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = 
            @"Server=DESKTOP-LRMHUDK\SQLEXPRESS;Database=Hospital;Integrated Security = True";
    }
}
