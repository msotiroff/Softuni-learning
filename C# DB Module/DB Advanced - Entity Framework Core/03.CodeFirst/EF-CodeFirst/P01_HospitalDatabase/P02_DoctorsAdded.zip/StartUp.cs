﻿namespace P01_HospitalDatabase
{
    using Data;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}