﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString =
                        @"Server=DESKTOP-LRMHUDK\SQLEXPRESS;Database=Sales;Integrated Security = True";
    }
}
