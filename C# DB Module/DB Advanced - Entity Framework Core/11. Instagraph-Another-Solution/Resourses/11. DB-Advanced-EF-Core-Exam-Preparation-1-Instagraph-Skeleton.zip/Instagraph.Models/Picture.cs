﻿namespace Instagraph.Models
{
    public class Picture
    {
        
    }
}
