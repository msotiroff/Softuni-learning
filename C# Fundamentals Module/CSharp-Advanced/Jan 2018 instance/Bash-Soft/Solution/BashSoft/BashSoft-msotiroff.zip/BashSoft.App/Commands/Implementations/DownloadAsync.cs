﻿namespace BashSoft.App.Commands.Implementations
{
    using Contracts;

    public class DownloadAsync : IInterpretable
    {
        public string Interpret(params string[] arguments)
        {
            throw new System.NotImplementedException();
        }
    }
}
