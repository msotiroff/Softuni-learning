﻿namespace LoggerSystem.App.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
