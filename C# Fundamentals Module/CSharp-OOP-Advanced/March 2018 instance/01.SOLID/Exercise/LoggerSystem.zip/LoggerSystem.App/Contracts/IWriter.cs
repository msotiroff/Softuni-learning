﻿namespace LoggerSystem.App.Contracts
{
    public interface IWriter
    {
        void WriteLine(string text);
    }
}
