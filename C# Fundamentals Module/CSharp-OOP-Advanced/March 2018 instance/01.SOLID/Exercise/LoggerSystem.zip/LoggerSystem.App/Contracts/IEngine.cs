﻿namespace LoggerSystem.App.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
